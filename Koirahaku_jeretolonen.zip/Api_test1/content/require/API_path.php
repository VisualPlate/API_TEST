<?php
    $apiUrl = "https://dog.ceo/api/breeds/image/random/";
?>